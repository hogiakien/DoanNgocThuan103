﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DoanNgocThuan103.Models
{
    public class Sell_DTO
    {
        public int month { get; set; }
        public float total { get; set; }

    }
}